import FormData from './FormData.vue'

export default FormData
