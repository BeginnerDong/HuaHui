<template>
  <div>
    <el-date-picker
      @change="onChange"
      v-model="submit_data[data.key]"
      v-bind="date_attrs"
      type="date"
      :placeholder="data.desc">
    </el-date-picker>
    
  </div>
</template>
<script>
  import Common from './js/Common'

  var Js = Common('sls-date')
  Js.mixins = [{
    computed: {
      date_attrs () {
        return this.Data.date_attrs || {}
      }
    },
    methods: {
      onChange (v) {
        this.$emit('onChange', [this.data.key,v]);
        //this.events.change && this.events.change(v)
      }
    },
    created () {

    }
  }]
  export default Js
</script>
