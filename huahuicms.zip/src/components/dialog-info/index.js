import DialogInfo from './DialogInfo.vue'

export default DialogInfo
