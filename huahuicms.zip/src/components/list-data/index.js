import ListData from './ListData.vue'

export default ListData
