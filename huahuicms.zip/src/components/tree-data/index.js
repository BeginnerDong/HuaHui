import TreeData from './TreeData.vue'

export default TreeData
