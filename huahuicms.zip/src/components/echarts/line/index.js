import Default from './default/'

export default {
  Default
}
