import Horizontal from './Horizontal.vue'

export default Horizontal
