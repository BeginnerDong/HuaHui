import Default from './default/'
import Horizontal from './horizontal/'

export default {
  Default,
  Horizontal
}
