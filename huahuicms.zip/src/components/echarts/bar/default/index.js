import Default from './Default.vue'

export default Default
