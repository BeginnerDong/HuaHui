import Bar from './bar/'
import Pie from './pie/'
import Line from './line/'

export default {
  Bar,
  Pie,
  Line
}
