import Common from './Common/'

export default {
  Common
}
