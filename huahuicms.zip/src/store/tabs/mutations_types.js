// 更新当前窗口列表
export const UPDATE_TABS = 'UPDATE_TABS'

// 移除当前窗口
export const REMOVE_TABS = 'REMOVE_TABS'
export const CLEAR_TABS = 'CLEAR_TABS'

