// 设置当前路由
export const SET_CUR_ROUTE = 'SET_CUR_ROUTE'
