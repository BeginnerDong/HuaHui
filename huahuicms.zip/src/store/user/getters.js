/**
 * Created by sailengsi on 2017/5/10.
 */

export default {
  getUserinfo (state) {
    return state.userinfo
  },

  getToken (state) {
    return state.token
  },

  getRemumber (state) {
    return state.remumber
  }
}
