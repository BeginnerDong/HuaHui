/**
 * Created by sailengsi on 2017/5/10.
 */

import order from './order.vue'


export default {
  order,
}