/**
 * Created by sailengsi on 2017/5/10.
 */

import Balance from './balance.vue'
import Score from './score.vue'
import pay from './pay.vue'

export default {
  Balance,
  Score,
  pay
}