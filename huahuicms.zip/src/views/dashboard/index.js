
import Dashboard from './dashboard.vue'
import Statistic from './statistic.vue'
import PicManage from './picManage.vue'


export default {
  Dashboard,
  Statistic,
  PicManage
}