/**
 * Created by sailengsi on 2017/5/10.
 */

import Message from './message.vue'
import Consult from './consult.vue'

export default {
  Message,
  Consult,
}