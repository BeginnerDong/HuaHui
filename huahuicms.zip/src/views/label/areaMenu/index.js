
import AreaMenu from './areaMenu.vue'

export default AreaMenu













