import Bar from './Bar.vue'

export default Bar
