import Pie from './Pie.vue'

export default Pie
