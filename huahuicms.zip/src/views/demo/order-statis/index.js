import Bar from './bar/'
import Pie from './pie/'

export default {
  Bar,
  Pie
}
