import Edit from './edit/'
import List from './list/'
import Access from './access/'

export default {
  Edit,
  List,
  Access
}
