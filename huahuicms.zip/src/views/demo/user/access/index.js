import Access from './Access.vue'

export default Access
