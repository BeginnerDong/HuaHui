import Article from './article/'
// import User from './user/';
import Order from './order/'
import OrderStatis from './order-statis/'

export default {
  Article,
  // User,
  Order,
  OrderStatis
}
