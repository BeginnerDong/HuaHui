/**
 * Created by sailengsi on 2017/5/10.
 */

import Product from './product.vue'
import Sku from './sku.vue'
import Coupon from './coupon.vue'

export default {
  Product,
  Sku,
  Coupon,
}
