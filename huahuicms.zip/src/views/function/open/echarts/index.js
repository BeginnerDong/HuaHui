import Echarts from './Echarts.vue'

export default Echarts
