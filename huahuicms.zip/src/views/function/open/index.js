import Echarts from './echarts/'
import Form from './form/'
import List from './list/'
import Vuex from './vuex/'
import Test404 from './test404/'

export default {
  Echarts,
  Form,
  List,
  Vuex,
  Test404
}
