import Test404 from './Test404.vue'

export default Test404
