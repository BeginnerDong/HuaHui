import Form from './Form.vue'

export default Form
