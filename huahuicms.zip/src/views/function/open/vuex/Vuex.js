import Shop from './shop/'

export default {
  name: 'vuex',
  components: Shop,
  data () {
    return {}
  },
  methods: {},
  created () {},
  mounted () {}
}
