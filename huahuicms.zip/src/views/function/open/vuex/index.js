import Vuex from './Vuex.vue'

export default Vuex
