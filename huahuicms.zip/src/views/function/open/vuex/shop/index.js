import Info from './info/'
import List from './list/'
import Cart from './cart/'

export default {
  Info,
  List,
  Cart
}
