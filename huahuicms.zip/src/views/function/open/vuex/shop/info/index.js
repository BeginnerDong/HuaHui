import Info from './Info.vue'

export default Info
