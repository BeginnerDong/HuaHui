import Cart from './Cart.vue'

export default Cart
