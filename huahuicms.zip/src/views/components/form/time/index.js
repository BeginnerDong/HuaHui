import Time from './Time.vue'

export default Time
