<template>
  <div class="form">
    <form-data
      :FieldList='fields'
      :DefaultValue="default_value"
      @onSubmit='onSubmit'></form-data>
  </div>
</template>
<script>
  import TimeJs from './Time.js'

  export default TimeJs
</script>
<style scoped>

</style>
