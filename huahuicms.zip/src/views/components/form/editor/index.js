import Editor from './Editor.vue'

export default Editor
