import Validate from './Validate.vue'

export default Validate
