import Checkbox from './Checkbox.vue'

export default Checkbox
