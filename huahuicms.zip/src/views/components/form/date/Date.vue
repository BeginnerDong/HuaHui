<template>
  <div class="form">
    <form-data
      :FieldList='fields'
      :DefaultValue="default_value"
      @onSubmit='onSubmit'></form-data>
  </div>
</template>
<script>
  import DateJs from './Date.js'

  export default DateJs
</script>
<style scoped>

</style>
