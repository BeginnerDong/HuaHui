import Input from './Input.vue'

export default Input
