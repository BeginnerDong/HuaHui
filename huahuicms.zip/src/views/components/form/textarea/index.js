import Textarea from './Textarea.vue'

export default Textarea
