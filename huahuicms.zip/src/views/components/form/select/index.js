import Select from './Select.vue'

export default Select
