import Search from './Search.vue'

export default Search
