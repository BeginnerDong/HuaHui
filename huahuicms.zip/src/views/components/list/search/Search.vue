<template>
  <div class="list">
    <list-data
      ref='list-data'
      :Search="search_data"
      @onSearch="onSearch"
      :List='list'
      :FieldList='fields'></list-data>
  </div>
</template>

<script>
  import SearchJs from './Search.js'

  export default SearchJs
</script>
<style scoped lang='less'>
  .demo-form-inline {
    display: inline-block;
    float: right;
  }

  .btm-action {
    margin-top: 20px;
    text-align: center;
  }

  .actions-top {
    height: 46px;
  }

  .pagination {
    display: inline-block;
  }
</style>
