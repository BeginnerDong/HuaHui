import Expand from './Expand.vue'

export default Expand
