import BtnCondition from './BtnCondition.vue'

export default BtnCondition
