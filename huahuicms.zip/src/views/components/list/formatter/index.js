import Formatter from './Formatter.vue'

export default Formatter
