import DataType from './DataType.vue'

export default DataType
