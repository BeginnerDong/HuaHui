import Filter from './Filter.vue'

export default Filter
