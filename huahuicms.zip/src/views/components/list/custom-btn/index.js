import CustomBtn from './CustomBtn.vue'

export default CustomBtn
