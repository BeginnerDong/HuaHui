/**
 * Created by sailengsi on 2017/5/10.
 */

import Login from './Login.vue'

export default Login
