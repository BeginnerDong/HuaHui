import Article from './article/'

export default {
  Article
}
