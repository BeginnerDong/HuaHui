import Edit from './edit/'
import List from './list/'

export default {
  Edit,
  List
}
