import Edit from './Edit.vue'

export default Edit
