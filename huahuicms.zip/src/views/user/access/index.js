import Access from './access.vue'

export default Access
