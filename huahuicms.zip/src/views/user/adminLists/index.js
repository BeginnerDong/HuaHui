import AdminLists from './adminLists.vue'

export default AdminLists

