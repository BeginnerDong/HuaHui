/**
 * Created by sailengsi on 2017/5/10.
 */

import ThirdApp from './thirdApp.vue'
import Wechat from './wechat.vue'
import Template from './template.vue'

export default {
  ThirdApp,
  Wechat,
  Template,
}
