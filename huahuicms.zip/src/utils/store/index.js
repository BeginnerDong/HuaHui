import store from './store.js'

export default store
